// TODO: deprecated since v8, remove this deprecation warning in v9
throw new Error('The file "mathjs/main/es5/index.js" has been moved since mathjs@8.0.0. ' +
  'Please load "mathjs" or "mathjs/lib/cjs/index.js" instead.')
