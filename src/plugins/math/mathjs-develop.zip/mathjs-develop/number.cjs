// TODO: deprecated since v8, remove this deprecation warning in v9
throw new Error('The file "mathjs/number.js" has been moved since mathjs@8.0.0. ' +
    'Please load "mathjs/number" or "mathjs/lib/esm/number.js" instead.')
